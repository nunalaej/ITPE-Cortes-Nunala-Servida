console.log("app.js started");

const express = require('express');
const mongoose = require('mongoose');
const app = express();


mongoose.connect('mongodb://localhost:27017/jyp-hospital', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const patientSchema = new mongoose.Schema({
  patientID: String,
  lastName: String,
  firstName: String,
  age: Number
});

const Patient = mongoose.model('Patient', patientSchema);

 
app.set('view engine', 'ejs');
app.use(express.static('public'));


app.get('/', async (req, res) => {
  const patients = await Patient.find().sort({ patientID: 1 });
  res.render('index', { patients });
});


const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
